import React from "react";

const Todo = ({ todo, toggleTodo, deleteTodo }) => {
  return (
    <li style={styles.item}>
      <span
        onClick={() => toggleTodo(todo.id)}
        style={{
          textDecoration: todo.completed ? "line-through" : "none",
          cursor: "pointer",
        }}
      >
        {todo.text}
      </span>
      <button onClick={() => deleteTodo(todo.id)} style={styles.deleteBtn}>
        ❌
      </button>
    </li>
  );
};

const styles = {
  item: {
    display: "flex",
    justifyContent: "space-between",
    background: "#f4f4f4ff",
    padding: "8px 12px",
    marginBottom: "8px",
    borderRadius: "5px",
  },
  deleteBtn: {
    background: "transparent",
    border: "none",
    cursor: "pointer",
    fontSize: "18px",
  },
};

export default Todo;
